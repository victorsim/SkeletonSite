SkeletonSite
============

Simple skeleton of a website (use for quick and dirty explorations of web ideas.)  Has jquery-1.10.2 (unminified).
